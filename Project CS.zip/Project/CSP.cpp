#include <iostream>
#include <vector>
#include <algorithm>
#include <stdexcept>

using namespace std;

const int KEY_SIZE = 5;

int egcd(int a, int b, int& x, int& y) {
    if (a == 0) {
        x = 0;
        y = 1;
        return b;
    }
    int gcd = egcd(b % a, a, x, y);
    int temp = x;
    x = y - (b / a) * x;
    y = temp;
    return gcd;
}

int modinv(int a, int m) {
    int x, y;
    int gcd = egcd(a, m, x, y);
    if (gcd != 1) throw invalid_argument("Modular inverse does not exist");
    return (x % m + m) % m;
}

string affine(const string& text, int a, int b, bool encrypt) {
    string result = "";
    for (char c : text) {
        if (c == ' ') result += ' ';
        else {
            int value = encrypt ? ((c - 'A') * a + b) % 26 : ((c - 'A' - b) * modinv(a, 26)) % 26;
            result += (value >= 0 ? value : value + 26) + 'A';
        }
    }
    return result;
}

void createKeyGrid(const string& key, char grid[KEY_SIZE][KEY_SIZE]) {
    int index = 0;
    bool used[26] = {false};

    for (char c : key) {
        c = toupper(c);
        if (!used[c - 'A']) {
            grid[index / KEY_SIZE][index % KEY_SIZE] = c;
            used[c - 'A'] = true;
            index++;
        }
    }

    for (char c = 'A'; c <= 'Z'; c++) {
        if (!used[c - 'A'] && c != 'J') {
            grid[index / KEY_SIZE][index % KEY_SIZE] = c;
            used[c - 'A'] = true;
            index++;
        }
    }
}

int findIndex(char ch, char grid[KEY_SIZE][KEY_SIZE]) {
    for (int i = 0; i < KEY_SIZE; i++) {
        for (int j = 0; j < KEY_SIZE; j++) {
            if (grid[i][j] == toupper(ch)) {
                return i * KEY_SIZE + j;
            }
        }
    }
    return -1;
}

string processText(const string& text) {
    string processedText;
    for (char c : text) {
        if (isalpha(c)) {
            processedText += toupper(c);
        }
    }

    for (int i = 0; i < processedText.size() - 1; i++) {
        if (processedText[i] == processedText[i + 1]) {
            processedText.insert(i + 1, "X");
            i++;
        }
    }
    return processedText;
}

string encrypt(const string& plaintext, char grid[KEY_SIZE][KEY_SIZE]) {
    string ciphertext;
    string processedText = processText(plaintext);

    for (int i = 0; i < processedText.size() - 1; i += 2) {
        int row1 = findIndex(processedText[i], grid) / KEY_SIZE;
        int col1 = findIndex(processedText[i], grid) % KEY_SIZE;
        int row2 = findIndex(processedText[i + 1], grid) / KEY_SIZE;
        int col2 = findIndex(processedText[i + 1], grid) % KEY_SIZE;

        if (row1 == row2) {
            ciphertext += grid[row1][(col1 + 1) % KEY_SIZE];
            ciphertext += grid[row2][(col2 + 1) % KEY_SIZE];
        } else if (col1 == col2) {
            ciphertext += grid[(row1 + 1) % KEY_SIZE][col1];
            ciphertext += grid[(row2 + 1) % KEY_SIZE][col2];
        } else {
            ciphertext += grid[row1][col2];
            ciphertext += grid[row2][col1];
        }
    }

    if (processedText.size() % 2 != 0) {
        int index = findIndex(processedText.back(), grid);
        int row = index / KEY_SIZE;
        int col = index % KEY_SIZE;
        char lastChar = (processedText.size() % 2 == 0) ? 'X' : processedText.back();

        if (col == KEY_SIZE - 1) {
            ciphertext += grid[(row + 1) % KEY_SIZE][0];
            ciphertext += grid[(row + 1) % KEY_SIZE][1];
        } else {
            ciphertext += grid[row][(col + 1) % KEY_SIZE];
            ciphertext += grid[row][(col + 2) % KEY_SIZE];
        }
    }

    for (char& c : ciphertext) {
        c = (c - 'A') + 'A';
    }

    return ciphertext;
}

string decrypt(const string& ciphertext, char grid[KEY_SIZE][KEY_SIZE]) {
    string plaintext;

    for (int i = 0; i < ciphertext.size() - 1; i += 2) {
        int row1 = findIndex(ciphertext[i], grid) / KEY_SIZE;
        int col1 = findIndex(ciphertext[i], grid) % KEY_SIZE;
        int row2 = findIndex(ciphertext[i + 1], grid) / KEY_SIZE;
        int col2 = findIndex(ciphertext[i + 1], grid) % KEY_SIZE;

        if (row1 == row2) {
            plaintext += grid[row1][(col1 + 4) % KEY_SIZE];
            plaintext += grid[row2][(col2 + 4) % KEY_SIZE];
        } else if (col1 == col2) {
            plaintext += grid[(row1 + 4) % KEY_SIZE][col1];
            plaintext += grid[(row2 + 4) % KEY_SIZE][col2];
        } else {
            plaintext += grid[row1][col2];
            plaintext += grid[row2][col1];
        }
    }

    if (ciphertext.size() % 2 != 0) {
        plaintext.pop_back();
    }

    return plaintext;
}

int main() {
    cout << "Welcome to the Genius Gang encryption program." << endl;
    while (true) {
        cout << "Choose the encryption/decryption method:" << endl;
        cout << "1. Affine Cipher" << endl;
        cout << "2. Playfair Cipher" << endl;
        int choice;
        cout << "Enter your choice (1 or 2): ";
        cin >> choice;

        if (choice == 1) {
            string plaintext;
            cout << "Enter the plaintext: ";
            cin.ignore();
            getline(cin, plaintext);
            transform(plaintext.begin(), plaintext.end(), plaintext.begin(), ::toupper);
            int a, b;
            cout << "Enter the value of 'a' (must be coprime with 26): ";
            cin >> a;
            cout << "Enter the value of 'b': ";
            cin >> b;
            string ciphertext = affine(plaintext, a, b, true);
            cout << "Encrypted text: " << ciphertext << endl;
            string decrypted_text = affine(ciphertext, a, b, false);
            cout << "Decrypted text: " << decrypted_text << endl;
        } else if (choice == 2) {
            string keyword, plaintext;
            cout << "Enter the keyword for Playfair cipher: ";
            cin >> keyword;
            cout << "Enter the plaintext: ";
            cin.ignore();
            getline(cin, plaintext);
            transform(keyword.begin(), keyword.end(), keyword.begin(), ::toupper);
            transform(plaintext.begin(), plaintext.end(), plaintext.begin(), ::toupper);
            char keygrid[KEY_SIZE][KEY_SIZE];
            createKeyGrid(keyword, keygrid);
            string ciphertext = encrypt(plaintext, keygrid);
            cout << "Encrypted text: " << ciphertext << endl;
            string decrypted_text = decrypt(ciphertext, keygrid);
            cout << "Decrypted text: " << decrypted_text << endl;
        } else {
            cout << "Invalid choice!" << endl;
        }

        string repeat;
        cout << "Do you want to encrypt/decrypt another message? (yes/no): ";
        cin >> repeat;
        if (repeat != "yes") {
            break;
        }
    }

    return 0;
}